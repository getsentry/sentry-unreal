#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface
NSDictionary (SentrySanitize)

- (NSDictionary *)sentry_sanitize;

@end

NS_ASSUME_NONNULL_END
