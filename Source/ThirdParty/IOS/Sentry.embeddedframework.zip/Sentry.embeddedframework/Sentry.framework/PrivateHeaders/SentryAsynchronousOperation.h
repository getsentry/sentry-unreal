#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SentryAsynchronousOperation : NSOperation

- (void)completeOperation;

@end

NS_ASSUME_NONNULL_END
